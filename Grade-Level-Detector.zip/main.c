#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int find_letters(string txt, int len);
int find_words(string txt, int len);
int find_sentences(string txt, int len);
int reading_calc(int letters, int sentences, int words);

// Main function
int main(void)
{
    // Input of text - TODO
    string text = get_string("Text: ");
    int string_length = strlen(text);

    // Variable for letters function
    int letter_count = find_letters(text, string_length);
    printf("Letters: %i\n", letter_count);

    int word_count = find_words(text, string_length);
    printf("Words: %i\n", word_count);

    int sentence_count = find_sentences(text, string_length);
    printf("Sentences: %i\n", sentence_count);

    int grade_level = reading_calc(letter_count, sentence_count, word_count);

    // Program for printing final grade

    if (grade_level < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (grade_level >= 1 && grade_level <= 16)
    {
        printf("Grade %i\n", grade_level);
    }
    else if (grade_level > 16)
    {
        printf("Grade 16+\n");
    }

}

// Function to find letters in text - DONE
int find_letters(string txt, int len)
{
    int num_letters = 0;

    for (int i = 0; i < len; i++)
    {
        if ( isdigit(txt[i]) == false && isspace(txt[i]) == false && ispunct(txt[i]) == false )
        {
            num_letters++;
        }
    }

    return num_letters;
}

// Function to find words in text - DONE
int find_words(string txt, int len)
{
    int num_words = 0;

    for (int i = 0; i < len; i++)
    {
        if ( isdigit(txt[i]) == false && isalpha(txt[i]) == false && ispunct(txt[i]) == false )
        {
            num_words++;
        }
    }

    return num_words + 1;
}

// Function to find sentences in a text - DONE
int find_sentences(string txt, int len)
{
    int num_sentences = 0;

    for (int i = 0; i < len; i++)
    {
        if (txt[i] == '.' || txt[i] == '!' || txt[i] == '?')
        {
            num_sentences++;
        }
    }

    return num_sentences;
}

// Function to calculate reading level - DONE
int reading_calc(int letters, int sentences, int words)
{
    // Setting double variables
    double dletters = letters;
    double dsentences = sentences;
    double dwords = words;

    // Creating average ratios
    double L = (dletters / dwords) * 100 ;
    double S = (dsentences / dwords) * 100 ;

    // Using index formula
    double precise_calc = (0.0588 * L) - (0.296 * S) - 15.8;
    int grade_value = round(precise_calc);

    return grade_value;
}